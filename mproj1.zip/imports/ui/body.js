import { Meteor} from 'meteor/meteor';
// get lib for template
import { Template } from 'meteor/templating';

// get lib filtering data
import { ReactiveDict } from 'meteor/reactive-dict';

// get data collections
// import { Tasks } from '../api/tasks.js';
import { Tasks } from '../../lib/tasks.js';

// get template 'task'
import './task.js';

// get view layout
import './body.html';


if (Meteor.isClient) {
	
	// Init state filter for body template
	Template.body.onCreated(
			function bodyOnCreated () {
				  this.state = new ReactiveDict();
				  Meteor.subscribe('tasks');
			}
	);


	// Let's update our client-side JavaScript code to get our tasks from a collection instead of a static array
	Template.body.helpers({
		tasks() {		

			const instance = Template.instance();// create instance 

			// // If hide completed is checked, filter tasks
			if (instance.state.get('hideCompleted')) {

				return Tasks.find({ checked: { $ne: true } }, {
					sort: { createdAt: -1 }
				});

			}

			// Otherwise, return all of the tasks
			return Tasks.find({}, {
				sort: { createdAt: -1}
			});
		},
		incompleteCount() {
			return Tasks.find({ checked: { $ne: true } }).count();
		},
	});

	// Add event handler for form submit
	Template.body.events({
		'submit .new-task'(event) {
			// Prevent default browser form submit
			event.preventDefault();

			// get value from form element
			const target = event.target;
			const text = target.text.value;

			// // Insert a task into the collection
			// Tasks.insert({
			// 	text,
			// 	createdAt: new Date(), // current time
			// 	owner: Meteor.userId(),
			// 	username: Meteor.user().username,
			// });
		
    		Meteor.call('tasks.insert', text);

			// clear form 
			target.text.value = '';
		},
		'change .hide-completed input'(event, instance) {	// changed for checkbox filter data
			instance.state.set('hideCompleted', event.target.checked);
		},
	});
}

