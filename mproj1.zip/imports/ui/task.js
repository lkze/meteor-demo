// // get Template
// import { Template } from 'meteor/templating';

// // get collections
// // import { Tasks } from '../api/tasks.js';
// import { Tasks } from '../../lib/tasks.js';

// // get view template
// import './task.html';


import {Meteor} from 'meteor/meteor';
import { Template } from 'meteor/templating';
 
import { Tasks } from '../../lib/tasks.js';
 
import './task.html';

if (Meteor.isClient) {

	// Process attribute and variable in template task
	Template.task.helpers({
		isOwner: function () {
			return this.owner === Meteor.userId();
		},
	});

	// Create events
	Template.task.events({
	  'click .toggle-checked'() {


	  	// console.log(Tasks);
	    // Set the checked property to the opposite of its current value

	    
	    // Tasks.update(this._id, {
	    //   $set: { checked: ! this.checked },
	    // });

	    Meteor.call('tasks.setChecked', this._id, !this.checked);
	  },
	  'click .delete'() {
	    // Tasks.remove(this._id);
	    Meteor.call('tasks.remove', this._id);
	  },
	  'click .toggle-private'() {
	    Meteor.call('tasks.setPrivate', this._id, !this.private);
	  },
	});
}
