// This is bootstrap files

// view body
import '../imports/ui/body.js';

// get data from user define
import '../lib/tasks.js';

// Import accounts configuration
import '../imports/startup/accounts-config.js';