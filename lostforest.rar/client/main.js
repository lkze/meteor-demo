import '../imports/startup/client';

// import '../imports/ui/layout/main-layout.js';
Meteor._reload.onMigrate(function() {
  return [false];
});