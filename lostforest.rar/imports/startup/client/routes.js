import { FlowRouter } from 'meteor/kadira:flow-router';
import { BlazeLayout } from 'meteor/kadira:blaze-layout';

// load layout
import '../../ui/layout/main-layout.js';
import '../../ui/layout/admin-layout.js';

// import to load templates front end
import '../../ui/pages/blog/blog-post.js';
import '../../ui/pages/blog/blog-list.js';
import '../../ui/pages/contact/contact.js';
import '../../ui/pages/about/about.html';
import '../../ui/pages/home/home.js';
import '../../ui/pages/app-not-found.js';

import '../../ui/pages/login/login.html';

// import to load templates back end
import '../../ui/pages/dashboard/dashboard.js';
import '../../ui/pages/dashboard/posts/posts-view.js';
import '../../ui/pages/dashboard/posts/posts-create.js';

FlowRouter.route('/', {
  name: 'home',
  action() {
    BlazeLayout.render('mainLayout', { main: 'home' });    
  },
});

FlowRouter.route('/about', {
  name: 'about',
  action() {
    BlazeLayout.render('mainLayout', { main: 'about' });
  },
});


FlowRouter.route('/contact', {
  name: 'contact',
  action() {
    BlazeLayout.render('mainLayout', { main: 'contact' });
  },
});

FlowRouter.route('/blog', {
  name: 'blogList', 
  action() {
    BlazeLayout.render('mainLayout', { main: 'blogList'});
  },
});

FlowRouter.route('/blog/:slug', {
  name: 'blogPost', 
  action(params, queryParams) {
    // console.log(this);
    // console.log(params);
    // console.log(queryParams);
    BlazeLayout.render('mainLayout', { main: 'blogPost'});
  },
});



// the App_notFound template is used for unknown routes and missing lists
FlowRouter.notFound = {
  action() {
    BlazeLayout.render('mainLayout', { main: 'App_notFound' });
  },
};

/**
*
* Pages Dashboard Admin
*
*/

// when login success redirect to adminLayout
FlowRouter.route('/login', {
  name: 'login', 
  action() {
    BlazeLayout.render('login');
  },
});

FlowRouter.route('/dashboard', {
  name: 'dashboard', 
  action(params, queryParams) {
    BlazeLayout.render('adminLayout', { main: 'dashboard'});
  },
});

FlowRouter.route('/dashboard/posts', {
  name: 'postsView', 
  action() {
    BlazeLayout.render('adminLayout', { main: 'postsView'});
  },
});

FlowRouter.route('/dashboard/posts/create', {
  name: 'postsCreate', 
  action() {
    BlazeLayout.render('adminLayout', { main: 'postsCreate'});
  },
});

FlowRouter.notFound = {
  action() {
    BlazeLayout.render('adminLayout', { main: 'App_notFound' });
  },
};