// get template libs
import { Template } from 'meteor/templating';

// get template views
import './slider.html';

Template.slidershow.helpers({
	carouselItems: [
	    { id: 0, title: 'Chania 1', imageUrl: '/img/slidershow/img_chania.jpg' },
	    { id: 1, title: 'Chania 2', imageUrl: '/img/slidershow/img_chania2.jpg' },
	    { id: 2, title: 'Flower 1', imageUrl: '/img/slidershow/img_flower.jpg' },
	    { id: 3, title: 'Flower 2', imageUrl: '/img/slidershow/img_flower2.jpg' },
  	],
	isActive: function () {
	    return (this.id === 0) ? 'active': '';
  	}
});