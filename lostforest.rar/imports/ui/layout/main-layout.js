// import { Template } from 'meteor/templating';
import './main-layout.html';
import '../components/navigationbar/nav-bar.js';