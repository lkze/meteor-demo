import {Template} from 'meteor/templating';
import {Meteor} from 'meteor/meteor';
// import { ReactiveDict } from 'meteor/reactive-dict';

// add jquery
import jQuery from 'jquery';
global.jQuery = global.$ = global.jquery = jQuery;

// get layout
import './admin-layout.html';

if(Meteor.isClient) {
	Template.adminLayout.events({
		'click #menu-toggle': function (event) {
			event.preventDefault();
			$('.main-admin').toggleClass('toggle');		
		}
	});
}