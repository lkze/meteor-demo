import { Template } from 'meteor/templating';

// connect collections data
import '../../../../lib/posts.js';

// get templates
import './blog-post.html';


if (Meteor.isClient) {

	console.log("Post sdfsdl ");
	Template.blogPost.onCreated(
		function() {
			var self = this;
			// console.log(this);
			self.autorun(function() {
				// console.log(this);
				self.subscribe('post', FlowRouter.getParam('postId'));
			});
		}

	);

	Template.blogPost.helpers({
		post: function () {
			
			return Posts.findOne({
				slug: FlowRouter.getParam('slug')
				/*
				sort: Sort specifier,
				skip: Number,
				fields: Field specifier,
				reactive: Boolean,
				transform: Function
				*/
			});
		}
	});


}
if (Meteor.isServer) {
	if (Posts.find().count() === 0) {
		Posts.insert(
		{
			slug: 'post-1', title: 'Post 1'
		},{
			slug: 'post-2', title: 'Post 2'
		},{
			slug: 'post-3', title: 'Post 3'
		},
		);
	}

	Meteor.publish('post', function() {
		check(slug, String);
		return Posts.find({ slug: slug });
	});
}