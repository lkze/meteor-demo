import { Template } from 'meteor/templating';
import { Meteor } from 'meteor/meteor';

import jQuery from 'jquery';
global.jQuery = global.$ = global.jquery = jQuery;

import './posts-update.html';

if (Meteor.isClient) {
	
}