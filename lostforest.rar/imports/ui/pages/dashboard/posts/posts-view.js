import { Meteor } from 'meteor/meteor';
import { Template } from 'meteor/templating';
import { Session } from 'meteor/session'

// import { FlowRouter } from 'meteor/kadira:flow-router';
// add jquery
import jQuery from 'jquery';
global.jQuery = global.$ = global.jquery = jQuery;


import './posts-view.html';


if (Meteor.isClient) {


	Template.postsView.onCreated(
		function postsOnCreated() {			
			Session.set('skip', 0);
			Tracker.autorun(function () {
				Meteor.subscribe('posts', Session.get('skip'));
			});
  			
  			// Session.set('page', 0);
		}		
	);
	Template.postsView.helpers({		
		posts: function() {
			return Posts.find({});
		},
		pagination: function() {

			// var totalRecord = Posts.find();

			// var currentPage = FlowRouter.getQueryParam("page");
			// if (!check(currentPage, Math.Integer)) {
			// 	currentPage = 0;
			// }

			
			// console.log(Session.get('skip'));
			// console.log(totalRecord);
			// console.log(currentPage);
			return '';
		}
	});

	Template.postsView.events({
		'click #prevPage': function (event) {
			event.preventDefault();		

			if(Session.get('skip') >= 2) {
				Session.set('skip', Session.get('skip') - 2);				
			} 
		},
		'click #nextPage': function (event) {
			event.preventDefault();

			var totalRecord = Posts.find().count();
			var limit = 2;
		
			if (totalRecord === limit) 
				Session.set('skip', Session.get('skip') + limit);
		}
	});


}