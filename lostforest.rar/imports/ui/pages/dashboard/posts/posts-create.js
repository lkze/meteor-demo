import { Meteor } from 'meteor/meteor';
import { Template } from 'meteor/templating';
import { FlowRouter } from 'meteor/kadira:flow-router';
// add jquery
import jQuery from 'jquery';
global.jQuery = global.$ = global.jquery = jQuery;

// get template
import './posts-create.html';

// connect collection data Posts
// import '../../../../../lib/posts.js';

if (Meteor.isClient) {

	// Template.postsCreate.helpers({
	// 	foo: function () {
	// 		// ...
	// 	}
	// });

	Template.postsCreate.events({
		'blur #post-title': function(event) {
			event.preventDefault();		

			var title = $('[name="post_title"]').val();
			title = $.trim(title);
			// title = title.replace(/\s+/g, '-');
			title = title.replace(/[^a-z0-9\s]/gi, '').replace(/\s+/g, '-');
			$('[name="post_slug"]').val(title);
			
		},
		'submit .form-post': function (event, tpl) {
			event.preventDefault();

			var title = tpl.$('input[name="post_title"]').val().replace(/[^a-z0-9\s]/gi, '');
			var slug = tpl.$('input[name="post_slug"]').val();
			if (slug == tpl.undefined || slug == '') {
				slug = title.replace(/\s+/g, '-');
			}
			var content = tpl.$('textarea[name="content"]').val();

			
			Meteor.call('posts.insert', title, slug, content, function (error, result) {
			 	if(error){
	                console.log(error.reason);
	            } else {
	            	// clear value form 
					tpl.$('input[name="post_title"]').val('');
					tpl.$('input[name="post_slug"]').val('');
					tpl.$('textarea[name="content"]').val('');

	                FlowRouter.go('/dashboard/posts');
	            }
			});
		}

	});
}
