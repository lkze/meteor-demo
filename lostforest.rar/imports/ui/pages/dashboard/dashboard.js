import {Meteor} from 'meteor/meteor';
// import { ReactiveDict } from 'meteor/reactive-dict';
// add jquery
import jQuery from 'jquery';
// global.jQuery = global.$ = global.jquery = jQuery;

import './dashboard.html';

