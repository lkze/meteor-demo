import '../../components/slider/slider.js';
import './home.html';