import { Template } from 'meteor/templating';

import './contact.html';

if (Meteor.isClient) {
	// Add and process attribute for HTML tag
	Template.contact.helpers({
		// foo: function () {
		// 	// ...
		// }
	});
	console.log('hello first name');
	// Events for 
	Template.contact.events({
		'blur input': function(event) {
			event.preventDefault();

			// get value from form element
			const first_name = event.target;



			const fn_name = first_name.first_name;


			//const first_name = target.first_name.value; // target.first_name ==> name attribute



			console.log(first_name.value);
			console.log(event);
			console.log(fn_name);
		},
		'click #contact-form': function () {
			
		}
	});	
}
